/**
 * state.js — single source of truth for app state
 */

const AppState = {
  currentStep:    0,
  startTime:      null,
  otpCode:        '',
  captchaTarget:  '',
  captchaCorrect: [],
  captchaAttempts:0,
  resendCount:    0,
  countdownTimer: null,

  reset() {
    this.currentStep     = 0;
    this.startTime       = null;
    this.otpCode         = '';
    this.captchaTarget   = '';
    this.captchaCorrect  = [];
    this.captchaAttempts = 0;
    this.resendCount     = 0;
    clearInterval(this.countdownTimer);
    this.countdownTimer  = null;
  },
};
