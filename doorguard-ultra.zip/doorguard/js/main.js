/**
 * main.js — Pipeline orchestrator and app bootstrap
 *
 * Wires together all steps and manages the overall flow.
 * Steps: 0=Captcha, 1=OTP, 2=Vibe, 3=Face, 4=Terms, 5=Countdown, 6=Success
 */

const STEP_RUNNERS = [
  () => Captcha.init(),
  () => OTP.init(),
  () => Vibe.init(),
  () => Face.init(),
  () => Terms.init(),
  () => Countdown.init(),
  () => Success.init(),
];

const Pipeline = {

  /** Mark a step done, advance to the next */
  advance(completedStep) {
    UI.setStep(completedStep, 'done');
    AppState.currentStep = completedStep + 1;
    UI.setStep(AppState.currentStep, 'active');
    STEP_RUNNERS[AppState.currentStep]();
  },

  /** Full reset back to initial state */
  reset() {
    AppState.reset();
    UI.hideAll();
    UI.lockDoor();
    UI.setStatus('Awaiting Authentication', true);
    for (let i = 0; i < 7; i++) UI.setStep(i, '');
    document.getElementById('open-btn').disabled = false;
  },
};

// ── BOOTSTRAP ──
document.addEventListener('DOMContentLoaded', () => {
  UI.startClock();

  document.getElementById('open-btn').addEventListener('click', () => {
    document.getElementById('open-btn').disabled = true;
    AppState.startTime = Date.now();
    UI.setStatus('Verifying identity...', true);
    UI.setStep(0, 'active');
    Captcha.init();
  });
});
