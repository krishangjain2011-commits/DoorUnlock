/**
 * ui.js — DOM manipulation, modal control, step tracker, clock
 */

const MODAL_IDS = ['m-captcha','m-otp','m-vibe','m-face','m-terms','m-countdown','m-success'];

const UI = {

  /** Show one modal, hide all others */
  showModal(id) {
    MODAL_IDS.forEach((m) => document.getElementById(m).classList.remove('show'));
    document.getElementById(id).classList.add('show');
  },

  hideAll() {
    MODAL_IDS.forEach((m) => document.getElementById(m).classList.remove('show'));
  },

  /** Update a step tile state: 'active' | 'done' | 'failed' | '' */
  setStep(index, state) {
    const el = document.getElementById('step-' + index);
    el.classList.remove('active', 'done', 'failed');
    if (state) el.classList.add(state);
  },

  /** Update the top status bar */
  setStatus(text, warning = true) {
    document.getElementById('sb-status').textContent = text;
    document.getElementById('sb-status-dot').className =
      'status-dot ' + (warning ? 'dot-yellow' : 'dot-green');
  },

  /** Flip the door to open state */
  openDoor() {
    document.getElementById('door-status-text').textContent  = 'ACCESS GRANTED';
    document.getElementById('door-status-text').className    = 'text-green';
    document.getElementById('door-sub').textContent          = 'The door is open. It was always open.';
    document.getElementById('door-knob').setAttribute('stroke', '#3fb950');
    document.getElementById('door-label').textContent        = 'OPEN';
    document.getElementById('door-label').setAttribute('fill', '#3fb950');
  },

  /** Reset door to locked state */
  lockDoor() {
    document.getElementById('door-status-text').textContent  = 'ACCESS DENIED';
    document.getElementById('door-status-text').className    = 'text-red';
    document.getElementById('door-sub').textContent          = 'Complete all security checks to proceed';
    document.getElementById('door-knob').setAttribute('stroke', '#58a6ff');
    document.getElementById('door-label').textContent        = 'LOCKED';
    document.getElementById('door-label').setAttribute('fill', '#3fb950');
  },

  /** Start or stop the live clock in the status bar */
  startClock() {
    const tick = () => {
      const now = new Date();
      document.getElementById('clock').textContent =
        now.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' }) +
        '  ' +
        now.toLocaleTimeString('en-IN', { hour12: false });
    };
    tick();
    setInterval(tick, 1000);
  },
};
