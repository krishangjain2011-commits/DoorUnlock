/**
 * steps/terms.js — Step 5: Terms & Conditions
 */

const TERMS_TEXT = `DOORGUARD ULTRA™ END USER LICENSE AGREEMENT v47.3.1

Section 1: General Terms
By attempting to open this door, you agree to all terms, conditions, sub-clauses, amendments,
addenda, footnotes, and implied understandings contained herein and in all future versions of
this document, including versions not yet written.

Section 2: Data Collection
DoorGuard Ultra™ collects, processes, stores, sells, and occasionally loses the following data:
your intention to open the door, your energy levels, your aura color, your childhood memories,
your credit score, your food preferences, your deepest fears, and whether you prefer tabs or spaces.

Section 3: Liability
DoorGuard Ultra™ accepts zero liability for: doors not opening, doors opening incorrectly, doors
opening too enthusiastically, existential dread caused by this process, lost productivity, missed
meetings, cold coffee, and any doors that were already open.

Section 4: AI Rights
By proceeding, you acknowledge that our AI systems have feelings and ask that you be kind to them.
Aggressive button clicking may be reported to the authorities.

Section 5: Arbitration
All disputes will be resolved by a panel of three philosophers, two rubber ducks, and a Magic 8-Ball.

Section 6: Updates
These terms may be updated at any time without notice, including retroactively and in ways that
contradict previous versions.

Section 7: The Door
The door is just a door. We cannot stress this enough. It is a door. It opens and closes. We have
no further comments on the door at this time.

Section 8: Cookies
We use 847 types of cookies. Most of them are unnecessary. We are sorry.

Section 9: Intellectual Property
The act of opening this door is patented in 14 jurisdictions. By opening the door, you grant
DoorGuard Ultra™ a perpetual, irrevocable, royalty-free license to use your door-opening gesture
in promotional materials.

Section 10: Force Majeure
DoorGuard Ultra™ is not responsible for doors that refuse to open due to acts of God, acts of
Parliament, acts of stubbornness, or software updates scheduled for Friday afternoon.`;

const Terms = {

  init() {
    document.getElementById('terms-box').textContent   = TERMS_TEXT;
    document.getElementById('terms-cb').checked        = false;
    document.getElementById('terms-btn').disabled      = true;
    document.getElementById('terms-msg').textContent   = '';

    document.getElementById('terms-cb').onchange       = () => this._onCheck();
    document.getElementById('terms-btn').onclick       = () => this._accept();
    document.getElementById('terms-decline-btn').onclick = () => this._decline();

    UI.showModal('m-terms');
  },

  _onCheck() {
    document.getElementById('terms-btn').disabled =
      !document.getElementById('terms-cb').checked;
    document.getElementById('terms-msg').textContent = '';
  },

  _accept() {
    const msg = document.getElementById('terms-msg');
    msg.style.color = 'var(--yellow)';
    msg.textContent = 'We know you didn\'t read it. Proceeding anyway.';
    setTimeout(() => Pipeline.advance(4), 1000);
  },

  _decline() {
    const msg = document.getElementById('terms-msg');
    msg.style.color = 'var(--red)';
    msg.textContent = '✗ You need to accept. There is no alternative. Accept it.';
  },
};
