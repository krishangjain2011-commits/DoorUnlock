/**
 * steps/otp.js — Step 2: Fax OTP verification
 */

const FAX_MESSAGES = [
  '📠 Resending... fax machine is warming up.',
  '📠 Fax sent again. Have you checked the paper tray?',
  '📠 Third attempt. We are also confused.',
  '📠 Our fax machine is tired. Please check yours.',
  '📠 Have you tried turning the fax machine off and on again?',
];

const OTP = {

  init() {
    AppState.otpCode     = String(randInt(100000, 999999));
    AppState.resendCount = 0;

    document.getElementById('otp-hint').textContent = AppState.otpCode;
    document.getElementById('otp-msg').textContent  = '';
    for (let i = 0; i < 6; i++) {
      const box = document.getElementById('otp' + i);
      box.value   = '';
      box.oninput = () => this._advance(i);
    }

    document.getElementById('otp-submit-btn').onclick = () => this.submit();
    document.getElementById('otp-resend-btn').onclick  = () => this.resend();

    document.getElementById('otp0').focus();
    UI.showModal('m-otp');
    toast('📠 Fax sent. Estimated delivery: Tuesday.');
  },

  _advance(i) {
    const val = document.getElementById('otp' + i).value;
    if (val && i < 5) document.getElementById('otp' + (i + 1)).focus();
  },

  resend() {
    AppState.resendCount++;
    AppState.otpCode = String(randInt(100000, 999999));
    document.getElementById('otp-hint').textContent = AppState.otpCode;
    toast(FAX_MESSAGES[Math.min(AppState.resendCount - 1, FAX_MESSAGES.length - 1)]);
  },

  submit() {
    const entered = [0,1,2,3,4,5]
      .map((i) => document.getElementById('otp' + i).value)
      .join('');
    const msg = document.getElementById('otp-msg');

    if (entered.length < 6) {
      msg.style.color   = 'var(--yellow)';
      msg.textContent   = '⚠ Please enter all 6 digits.';
      return;
    }
    if (entered === AppState.otpCode) {
      msg.style.color = 'var(--green)';
      msg.textContent = '✓ Code accepted. Your fax machine works. Impressive.';
      setTimeout(() => Pipeline.advance(1), 900);
    } else {
      msg.style.color = 'var(--red)';
      msg.textContent = '✗ Incorrect code. (The hint is right there.)';
    }
  },
};
