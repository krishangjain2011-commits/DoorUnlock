/**
 * steps/captcha.js — Step 1: CAPTCHA verification
 */

const CAPTCHA_TILES = [
  { e: '🚗', l: 'cars' },     { e: '🚕', l: 'cars' },    { e: '🚙', l: 'cars' },
  { e: '🚌', l: 'buses' },    { e: '🚎', l: 'buses' },
  { e: '🚦', l: 'traffic lights' }, { e: '🚥', l: 'traffic lights' },
  { e: '🔥', l: 'fire' },     { e: '💧', l: 'water' },
  { e: '🌲', l: 'trees' },    { e: '🌳', l: 'trees' },
  { e: '🏠', l: 'houses' },   { e: '🏡', l: 'houses' },
  { e: '🐱', l: 'cats' },     { e: '🐶', l: 'dogs' },
];

const EXISTENTIAL_PROMPTS = [
  'your will to open doors',
  'the concept of security',
  'things that bring you joy',
  'your deepest regrets',
  'tiles that feel like a Monday',
  'signs of sentience',
];

const Captcha = {

  init() {
    document.getElementById('captcha-submit-btn').onclick  = () => this.submit();
    document.getElementById('captcha-refresh-btn').onclick = () => this.build();
    this.build();
    UI.showModal('m-captcha');
  },

  build() {
    AppState.captchaAttempts = 0;
    document.getElementById('captcha-msg').textContent = '';
    const grid = document.getElementById('captcha-grid');
    grid.innerHTML = '';

    const useExistential = Math.random() < 0.4;

    if (useExistential) {
      AppState.captchaTarget  = randomPick(EXISTENTIAL_PROMPTS);
      AppState.captchaCorrect = [];
      document.getElementById('captcha-ask').textContent = AppState.captchaTarget;
      for (let i = 0; i < 16; i++) {
        grid.appendChild(this._makeTile(randomPick(CAPTCHA_TILES).e, false));
      }
    } else {
      const target  = randomPick(CAPTCHA_TILES);
      AppState.captchaTarget = target.l;
      document.getElementById('captcha-ask').textContent = target.l;

      const pool = [];
      const correctCount = randInt(2, 4);
      const matching = CAPTCHA_TILES.filter((t) => t.l === target.l);

      for (let i = 0; i < correctCount; i++) {
        pool.push({ e: randomPick(matching).e, correct: true });
      }
      while (pool.length < 16) {
        const t = randomPick(CAPTCHA_TILES);
        if (t.l !== target.l) pool.push({ e: t.e, correct: false });
      }
      pool.sort(() => Math.random() - 0.5);
      AppState.captchaCorrect = pool.map((p) => p.correct);
      pool.forEach((item) => grid.appendChild(this._makeTile(item.e, false)));
    }
  },

  _makeTile(emoji) {
    const d = document.createElement('div');
    d.className = 'cap-tile';
    d.textContent = emoji;
    d.onclick = () => d.classList.toggle('selected');
    return d;
  },

  submit() {
    const tiles    = document.querySelectorAll('.cap-tile');
    const selected = Array.from(tiles).map((t) => t.classList.contains('selected'));
    const msg      = document.getElementById('captcha-msg');
    AppState.captchaAttempts++;

    // Existential CAPTCHA — no right answer, pass after 2 attempts
    if (EXISTENTIAL_PROMPTS.includes(AppState.captchaTarget)) {
      if (AppState.captchaAttempts < 2) {
        this._fail(msg, '✗ Incorrect. Please try again. (Hint: there is no correct answer.)');
      } else {
        this._pass(msg, '✓ Sure, why not. Human enough.');
      }
      return;
    }

    const correct = AppState.captchaCorrect.every((c, i) => c === selected[i]);
    if (correct) {
      this._pass(msg, '✓ Verification passed. Suspiciously fast, though.');
    } else if (AppState.captchaAttempts === 1) {
      this._fail(msg, '✗ Wrong. Are you sure you\'re human?');
    } else if (AppState.captchaAttempts === 2) {
      this._fail(msg, '✗ Still wrong. ChatGPT would have got this.');
      this.build();
    } else {
      this._pass(msg, '✓ Fine. We\'ll let it slide. Moving on.');
    }
  },

  _pass(msgEl, text) {
    msgEl.style.color = 'var(--green)';
    msgEl.textContent = text;
    setTimeout(() => Pipeline.advance(0), 900);
  },

  _fail(msgEl, text) {
    msgEl.style.color = 'var(--red)';
    msgEl.textContent = text;
    document.querySelectorAll('.cap-tile.selected').forEach((t) => {
      t.classList.add('wrong');
      setTimeout(() => t.classList.remove('wrong'), 500);
    });
  },
};
