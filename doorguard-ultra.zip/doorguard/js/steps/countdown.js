/**
 * steps/countdown.js — Step 6: Final countdown confirmation
 */

const Countdown = {

  _value: 10,

  init() {
    this._value = 10;
    document.getElementById('countdown-num').textContent  = 10;
    document.getElementById('countdown-num').style.color  = 'var(--red)';
    document.getElementById('countdown-msg').textContent  = 'Auto-cancelling if you do nothing...';
    document.getElementById('confirm-btn').disabled       = false;

    document.getElementById('confirm-btn').onclick = () => this._confirm();
    document.getElementById('cancel-btn').onclick  = () => this._cancel();

    UI.showModal('m-countdown');
    this._tick();
  },

  _tick() {
    AppState.countdownTimer = setInterval(() => {
      this._value--;
      document.getElementById('countdown-num').textContent = this._value;

      if (this._value <= 3) {
        document.getElementById('countdown-msg').textContent = 'Hurry up...';
      }
      if (this._value <= 0) {
        clearInterval(AppState.countdownTimer);
        document.getElementById('countdown-msg').textContent = 'Time\'s up. Starting over.';
        document.getElementById('confirm-btn').disabled = true;
        setTimeout(() => {
          UI.hideAll();
          Pipeline.reset();
          toast('⏱ Timed out. All progress lost. Sorry about that.');
        }, 1200);
      }
    }, 1000);
  },

  _confirm() {
    clearInterval(AppState.countdownTimer);
    Pipeline.advance(5);
  },

  _cancel() {
    clearInterval(AppState.countdownTimer);
    UI.hideAll();
    Pipeline.reset();
    toast('Wise choice. The door will still be there tomorrow.');
  },
};
