/**
 * steps/success.js — Step 7: Access granted
 */

const Success = {

  init() {
    const elapsed = ((Date.now() - AppState.startTime) / 1000).toFixed(1);
    document.getElementById('final-time').textContent = elapsed + ' seconds';

    UI.openDoor();
    UI.setStatus('Access granted', false);
    UI.showModal('m-success');

    document.getElementById('reset-btn').onclick = () => Pipeline.reset();
  },
};
