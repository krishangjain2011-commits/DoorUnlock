/**
 * steps/face.js — Step 4: Biometric / facial expression analysis
 */

const FACE_SEQUENCE = [
  { e: '😐', t: 'Detecting face...',                              ms: 700  },
  { e: '🔍', t: 'Analyzing bone structure...',                    ms: 800  },
  { e: '😤', t: 'Assessing determination level...',               ms: 700  },
  { e: '🤔', t: 'Checking for suspicious eyebrows...',            ms: 900  },
  { e: '😑', t: 'Cross-referencing with LinkedIn photo...',       ms: 800  },
  { e: '😮', t: 'Comparing to your Facebook profile from 2011...', ms: 900 },
  { e: '🧐', t: 'Evaluating "do they really need this door" index...', ms: 1000 },
];

const FACE_VERDICTS = [
  'Expression: Mildly desperate. Door access: Granted.',
  'Expression: Determined but tired. Door access: Reluctantly granted.',
  'Eyebrows: Slightly suspicious. Override: Approved.',
  'Expression: Looks like someone who\'s survived too many CAPTCHAs. Granted.',
  'Face: Human (probably). Proceeding.',
  'Vibe-to-face correlation: Consistent. Surprisingly.',
];

const Face = {

  async init() {
    document.getElementById('face-result').textContent        = '';
    document.getElementById('face-next-btn').style.display    = 'none';
    document.getElementById('face-next-btn').onclick          = () => Pipeline.advance(3);

    UI.showModal('m-face');
    await this._run();
  },

  async _run() {
    const emoji   = document.getElementById('face-emoji');
    const verdict = document.getElementById('face-verdict');

    for (const step of FACE_SEQUENCE) {
      emoji.textContent   = step.e;
      verdict.textContent = step.t;
      await delay(step.ms);
    }

    emoji.textContent   = '✅';
    verdict.textContent = 'Scan complete.';

    const res = document.getElementById('face-result');
    res.style.color = 'var(--green)';
    res.textContent = randomPick(FACE_VERDICTS);

    document.getElementById('face-next-btn').style.display = 'inline-block';
  },
};
