/**
 * steps/vibe.js — Step 3: AI Vibe Analysis
 */

const VIBE_PARAMS = [
  'Mouse movement entropy',
  'Typing rhythm variance',
  'Click pressure analysis',
  'Scroll behavior pattern',
  'Time-of-day energy index',
  'Tab count psychology',
  'Keyboard shortcut usage',
  'Password manager dependency',
  'Stack Overflow visits today',
  'GitHub commit message quality',
  'Variable naming sentiment',
  'Readme writing enthusiasm',
];

const Vibe = {

  async init() {
    document.getElementById('vibe-bar').style.width = '0%';
    document.getElementById('vibe-questions').innerHTML = '';
    document.getElementById('vibe-result').textContent  = '';
    document.getElementById('vibe-next-btn').style.display = 'none';
    document.getElementById('vibe-next-btn').onclick = () => Pipeline.advance(2);

    UI.showModal('m-vibe');
    await this._run();
  },

  async _run() {
    const bar     = document.getElementById('vibe-bar');
    const status  = document.getElementById('vibe-status');
    const qbox    = document.getElementById('vibe-questions');

    const params = [...VIBE_PARAMS].sort(() => Math.random() - 0.5).slice(0, 5);
    let total = 0;

    for (let i = 0; i < params.length; i++) {
      status.textContent = 'Analyzing: ' + params[i] + '...';
      await delay(randInt(500, 900));

      const score = parseFloat(randFloat(6, 9.8));
      total += score;

      const row = document.createElement('div');
      row.className = 'vibe-q';
      row.innerHTML = `<span>${params[i]}</span><span class="vibe-score">${score.toFixed(1)}/10</span>`;
      qbox.appendChild(row);

      bar.style.width = Math.round(((i + 1) / params.length) * 100) + '%';
    }

    const avg = (total / params.length).toFixed(1);
    await delay(400);
    status.textContent = 'VibeNet™ verdict: ' + avg + '/10';

    const res = document.getElementById('vibe-result');
    if (avg >= 7.5) {
      res.style.color = 'var(--green)';
      res.textContent = '✓ Vibe: Acceptable. You may be door-worthy.';
    } else {
      res.style.color = 'var(--yellow)';
      res.textContent = '⚠ Vibe: Questionable. Proceeding under protest.';
    }

    document.getElementById('vibe-next-btn').style.display = 'inline-block';
  },
};
