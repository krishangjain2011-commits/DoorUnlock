/**
 * utils.js — shared helper functions
 */

/** Promise-based sleep */
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Show a toast notification */
function toast(msg, duration = 2800) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), duration);
}

/** Pick a random item from an array */
function randomPick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** Generate a random integer between min and max (inclusive) */
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/** Generate a random float with fixed decimal places */
function randFloat(min, max, decimals = 1) {
  return (Math.random() * (max - min) + min).toFixed(decimals);
}
